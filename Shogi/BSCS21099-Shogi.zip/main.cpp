#include <iostream>
#include "Shogi.h"

int main()
{
	Shogi S;
	S.play();
}